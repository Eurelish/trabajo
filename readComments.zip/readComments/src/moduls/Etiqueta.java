package moduls;


public class Etiqueta {
    public final static int
            NUM = 256, ID = 257, TRUE = 258, FALSE = 259, SUMA = 260, RESTA = 261, DIVICION = 262, MULTIPLICACION = 263,
            MENORQUE = 264, MAYORQUE = 265, MENORIGUALQUE = 266, MAYORIGUALQUE = 267, IGUAL = 268, COMPARACION = 269, DOCUMENTACION = 270;
}