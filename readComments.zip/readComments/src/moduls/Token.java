package moduls;

public class Token {
    public final int etiqueta;
    public Token(int t) {etiqueta = t; }

    public int getEtiqueta() {
        return etiqueta;
    }
}